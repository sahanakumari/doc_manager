package com.rajyadavnp.doc_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
