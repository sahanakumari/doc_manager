typedef ButtonSlideCallBack = Future<bool> Function();
typedef StatusChangeCallback = Function(String status);

typedef StepperTapCallback = Future<bool> Function(int count);
